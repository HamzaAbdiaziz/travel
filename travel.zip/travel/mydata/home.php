<div class="tab-pane fade show active" id="homepage">

  <div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">

      <div class="col-lg-12 col-md-12 order-1">
        <div class="row">

         <body style="background-image: url('assets/img/travel2.webp');">
          
         </body>

        </div>
      </div>


    </div>

  </div>
</div>




<div class="tab-pane fade" id="register" role="tabpanel">
  <div class="col-md-12">
    <div class="nav-align-top mb-4">
      <ul class="nav nav-pills mb-3 nav-fill" role="tablist">
        <li class="nav-item">
          <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab" data-bs-target="#tb_airsplane" aria-controls="tb_airsplane" aria-selected="true">
            <i class="tf-icons bx bx-home"></i> Airsplane

          </button>
        </li>

        <li class="nav-item">
          <button type="button" class="nav-link " role="tab" data-bs-toggle="tab" data-bs-target="#tb_country" aria-controls="tb_country" aria-selected="true">
            <i class="tf-icons bx bx-home"></i> country

          </button>
        </li>

        <li class="nav-item">
          <button type="button" class="nav-link " role="tab" data-bs-toggle="tab" data-bs-target="#tb_Passengers" aria-controls="tb_Passengers" aria-selected="true">
            <i class="tf-icons bx bx-home"></i> Passengers

          </button>
        </li>

        <li class="nav-item">
          <button type="button" class="nav-link " role="tab" data-bs-toggle="tab" data-bs-target="#tb_employee" aria-controls="tb_employee" aria-selected="true">
            <i class="tf-icons bx bx-home"></i> Employee

          </button>
        </li>
       
      </ul>

      <div class="tab-content">
        <div class="tab-pane fade show active" id="tb_airsplane" role="tabpanel">
          <div class="col-md-6">

            <button type="button" class="btn btn-primary btn_new_airsplane" data-bs-toggle="modal" data-bs-target="#mdl_airsplane">
            Add airsplane
            </button>

          </div>

          <div class="col-md-12">
            <div class="table-responsive">
              <div id="tbl_id_airsplane" class="tbl_cls_airsplane">
                <?php $coder->Table("CALL airsplane_view()", "dt_airsplane", "n") ?>
              </div>
            </div>
          </div>


        </div>

        
        <div class="tab-pane fade" id="tb_country" role="tabpanel">
          <div class="col-md-6">
            <button type="button" class="btn btn-primary mb-2 btn_new_countries" data-bs-toggle="modal" data-bs-target="#mdl_countries">
              Add countries
            </button>

          </div>



          <div class="col-md-12">
            <div class="table-responsive">
              <div id="tbl_id_countries" class="tbl_cls_countries">
                <?php $coder->Table("CALL countries_view()", "dt_countries", "n") ?>
              </div>
            </div>
          </div>

        </div>



        <div class="tab-pane fade show " id="tb_Passengers" role="tabpanel">
          <div class="col-md-6">

            <button type="button" class="btn btn-primary btn_new_Passengers" data-bs-toggle="modal" data-bs-target="#mdl_Passengers">
            Add Passengers
            </button>

          </div>

          <div class="col-md-12">
            <div class="table-responsive">
              <div id="tbl_id_Passengers" class="tbl_cls_Passengers">
                <?php $coder->Table("CALL Passengers_view()", "dt_Passengers", "n") ?>
              </div>
            </div>
          </div>


        </div>

       
        <div class="tab-pane fade" id="tb_employee" role="tabpanel">
          <div class="col-md-6">
            <button type="button" class="btn btn-primary mb-2 btn_new_employee" data-bs-toggle="modal" data-bs-target="#mdl_employee">
              Add employee
            </button>

          </div>



          <div class="col-md-12">
            <div class="table-responsive">
              <div id="tbl_id_employee" class="tbl_cls_employee">
                <?php $coder->Table("CALL employee_view()", "dt_employee", "n") ?>
              </div>
            </div>
          </div>

        </div>



      </div>

    </div>
  </div>
</div>














<div class="tab-pane fade" id="Schedule" role="tabpanel">

  <div class="col-md-12">
    <div class="nav-align-top mb-4">
      <ul class="nav nav-pills mb-3 nav-fill" role="tablist">
        <li class="nav-item">
          <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab" data-bs-target="#tb_flight" aria-controls="tb_flight" aria-selected="true">
            <i class="tf-icons bx bx-home"></i>Flight
            
          </button>
        </li>
        
        
      </ul>
      <div class="tab-content">
        <div class="tab-pane fade show active" id="tb_flight" role="tabpanel">
        
        <div class="col-md-6">
        <button type="button" class="btn btn-primary mb-2 btn_new_flight" data-bs-toggle="modal" data-bs-target="#mdl_flight">
              Add flight
            </button>
        </div>

        <div class="col-md-12">
          <div class="table-responsive">
          <div id="tbl_id_flight" class="tbl_cls_flight">
                <?php $coder->Table("CALL flight_view()", "dt_flight", "n") ?>
              </div>
          </div>
        </div>

        </div>
        
        
      </div>
    </div>
  </div>

</div>




<div class="tab-pane fade" id="Ticket" role="tabpanel">

  <div class="col-md-12">
    <div class="nav-align-top mb-4">
      <ul class="nav nav-pills mb-3 nav-fill" role="tablist">
        <li class="nav-item">
          <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab" data-bs-target="#tb_Ticket" aria-controls="tb_Ticket" aria-selected="true">
            <i class="tf-icons bx bx-home"></i>Ticket
            
          </button>
        </li>
        
        
      </ul>
      <div class="tab-content">
        <div class="tab-pane fade show active" id="tb_Ticket" role="tabpanel">
        
        <div class="col-md-6">
        <button type="button" class="btn btn-primary mb-2 btn_new_Ticket" data-bs-toggle="modal" data-bs-target="#mdl_Ticket">
              Add Ticket
            </button>
        </div>

        <div class="col-md-12">
          <div class="table-responsive">
          <div id="tbl_id_Ticket" class="tbl_cls_Ticket">
                <?php $coder->Table("CALL Ticket_view()", "dt_Ticket", "n") ?>
              </div>
          </div>
        </div>

        </div>
        
        
      </div>
    </div>
  </div>

</div>









<div class="tab-pane fade" id="fianance" role="tabpanel">

  <div class="col-md-12">
    <div class="nav-align-top mb-4">
      <ul class="nav nav-pills mb-3 nav-fill" role="tablist">
        <li class="nav-item">
          <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab" data-bs-target="#tb_accounts" aria-controls="tb_accounts" aria-selected="true">
            <i class="tf-icons bx bx-home"></i>accounts
            
          </button>
        </li>

        <li class="nav-item">
          <button type="button" class="nav-link " role="tab" data-bs-toggle="tab" data-bs-target="#tb_expense_payment" aria-controls="tb_expense_payment" aria-selected="true">
            <i class="tf-icons bx bx-home"></i>expense_payment
            
          </button>
        </li>
        
        
      </ul>
      <div class="tab-content">
        <div class="tab-pane fade show active" id="tb_accounts" role="tabpanel">
        
        <div class="col-md-6">
        <button type="button" class="btn btn-primary mb-2 btn_new_accounts" data-bs-toggle="modal" data-bs-target="#mdl_accounts">
              Add accounts
            </button>
        </div>

        <div class="col-md-12">
          <div class="table-responsive">
          <div id="tbl_id_accounts" class="tbl_cls_accounts">
                <?php $coder->Table("CALL accounts_view()", "dt_accounts", "n") ?>
              </div>
          </div>
        </div>

        </div>

        <div class="tab-pane fade show " id="tb_expense_payment" role="tabpanel">
        
        <div class="col-md-6">
        <button type="button" class="btn btn-primary mb-2 btn_new_expense_payment" data-bs-toggle="modal" data-bs-target="#mdl_expense_payment">
              Add expense_payment
            </button>
        </div>

        <div class="col-md-12">
          <div class="table-responsive">
          <div id="tbl_id_expense_payment" class="tbl_cls_expense_payment">
                <?php $coder->Table("CALL expense_payment_view()", "dt_expense_payment", "n") ?>
              </div>
          </div>
        </div>

        </div>
        
        
      </div>
    </div>
  </div>

</div>




<!-- Tichet_report Tap -->
<div class="tab-pane fade" id="Tichet_report">

    <div class="col-md-12 col-xl-12">
        <!-- <h6 class="text-muted">Registration Area</h6> -->
        <div class="nav-align-top mb-4">
            <ul class="nav nav-pills mb-3 nav-fill" role="tablist">
                <li class="nav-item">
                    <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab" data-bs-target="#tb_Ticket_reports" aria-controls="tb_Ticket_reports" aria-selected="true">
                        <i class="tf-icons bx bx-home"></i> Ticket_reports
                        <!-- <span class="badge rounded-pill badge-center h-px-20 w-px-20 bg-danger">3</span> -->
                    </button>
                </li>
                <li class="nav-item">
                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#tb_empReport" aria-controls="tb_empReport" aria-selected="false">
                        <i class="tf-icons bx bx-user"></i> Employee
                    </button>
                </li>
               
                <li class="nav-item">
                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#tb_flight_reports" aria-controls="tb_flight_reportst" aria-selected="false">
                        <i class="tf-icons bx bx-user"></i>flight_reports
                    </button>
                </li>

            </ul>
            <div class="tab-content">
                <div class="tab-pane fade show active" id="tb_Ticket_reports" role="tabpanel">
                    <div class="col-md-12">
                        <!-- <button type="button" class="btn btn-primary mb-2 btn_new_address" data-bs-toggle="modal"
                        data-bs-target="#address">
                        address
                    </button> -->
                    <div class="flex" style="display: flex; margin-left: 15%;">
                            <div class="col-md-3 mt-3">
                                <label for="">Date1</label>
                                <input type="date" class="form-control" id="ticket_date1">
                            </div>
                            <div class="col-md-3 mt-3" >
                                <label for="">Date2</label>
                                <input type="date" class="form-control" id="ticket_date2">
                            </div>
                            </div>
                      
                    
                    <div class="col-md-4">
                    <?php $coder->fillCombo("SELECT Ticket_no, p.name FROM ticket t, passengers p WHERE p.Passengers_no=t.Passengers_no ORDER BY name", "cbm_ticket_print", "Select ticket"); ?>
                    </div>
                       
                    <div class="col-md-8">

                        <button class="btn btn-md col-md-5 mt-3 btn-primary btn_tikchet_info">All Ticke Report</button>

                        <button class="btn btn-md col-md-5 mt-3 w-60 btn-primary btn_tikchet_two_dates">Ticke Report two dates </button>

                        <button class="btn btn-md col-md-5 mt-3 w-60 btn-primary btn_ticke_Report_Single">Ticke Report Single </button>


                      </div>

                      <!-- <div class="col-md-4">

                        <button class="btn btn-md col-md-5 mt-3 btn-primary btn_tikchet_two_dates">Ticke Report two dates </button>

                      </div> -->

                    </div>



                </div>


                <div class="tab-pane fade show " id="tb_empReport" role="tabpanel">
                    <div class="col-md-12">
                        <!-- <button type="button" class="btn btn-primary mb-2 btn_new_address" data-bs-toggle="modal"
                        data-bs-target="#address">
                        address
                    </button> -->
                    <div class="col-md-4">
                    <?php $coder->fillCombo("SELECT Employee_no, name FROM employee ORDER BY name", "cbm_employee_print", "Select employee"); ?>
                    </div>
                        <button class="btn btn-md col-md-5 mt-3 btn-primary btn_employee_single"> single report employee </button>
                        <button class="btn btn-md col-md-5 mt-3 btn-primary btn_employee_all"> All report employee </button>




                    </div>



                </div>


                <div class="tab-pane fade show " id="tb_flight_reports" role="tabpanel">
                    <div class="col-md-12">
                    
                    <div class="col-md-4">
                    <?php $coder->fillCombo("SELECT flight_no, a.airsplane_name FROM airsplane a, flight f WHERE a.airsplane_no=f.airsplane_no  ORDER BY flight_no", "cbm_flight_print", "Select flight"); ?>
                    </div>
                    
                    <div class="col-md-4">

                    </div>
                        <button class="btn btn-md col-md-5 mt-3 btn-primary btn_single_flight_reports"> single flight_reports </button>
                        <button class="btn btn-md col-md-5 mt-3 btn-primary btn_flight_report_all"> All flight_reports </button>

                      </div>



                </div>
                


            </div>
        </div>
    </div>

</div>
<!-- end Tichet_report Tap -->
