

<!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>



  <script>
    new DataTable('#example');
</script>

<script>
    // $('#summernote').summernote({
    // 	placeholder: '',
    // 	tabsize: 2,
    // 	height: 200
    // });
    $(document).ready(function() {
        $.fn.dataTableExt.sErrMode = 'throw';
        //$('.selects').select2();
        $('.tables').DataTable();
        // Javascript method's body can be found in assets/js/demos.js
        md.initDashboardPageCharts();
        md.initVectorMap();
    });

    function SYD_ALL(modalName, qry, groupBy) {

        var tbl_name = modalName.replace("mdl_", "");
        $(document).delegate(".btn_edit_" + tbl_name, "click", function(e) {
            $("#" + tbl_name + "_alert").hide();
            var up_id = $(this).val();
            $("#btn_save_" + tbl_name).hide();
            $("#btn_update_" + tbl_name).show();
            var qry1 = qry + up_id + " " + groupBy;
            $.post("config/SYD_search.php", "qry=" + qry1.replace(/\s/g, "^"), function(data) {
                var array = data.split(",");
                var a = 0;
                $('#frm_' + tbl_name).find(':input').each(function() {
                    if (this.id != "" && this.type != "button" && this.type != "submit") {
                        $("#" + this.id).val(array[a]);
                        $('.selects').trigger('change');
                        a = a + 1;
                    }
                });

            });
            $("#" + modalName).modal('show');
            return false;
        });
        $(document).delegate(".btn_remove_" + tbl_name, "click", function(e) {
            $("#" + tbl_name + "_alert").hide();
            var up_id = $(this).val();
            $("#btn_save_" + tbl_name).hide();
            $("#btn_update_" + tbl_name).show();
            var qry1 = qry + up_id + " " + groupBy;
            $.post("config/SYD_search.php", "qry=" + qry1.replace(/\s/g, "^"), function(data) {
                var array = data.split(",");
                var a = 0;
                $('#frm_' + tbl_name).find(':input').each(function() {
                    if (this.id != "" && this.type != "button" && this.type != "submit") {
                        $("#" + this.id).val(array[a]);
                        $('.selects').trigger('change');
                        a = a + 1;
                    }
                });

            });
            $('#yes_d_btn').attr('class', "btn btn-danger btn-sm btn-circle btn_delete_" + tbl_name);
            $("#mdl_delete_all").modal('show');
            return false;
        });
        $(document).delegate(".btn_new_" + tbl_name, "click", function(e) {
            // alert(tbl_name)
            $("#" + tbl_name + "_alert").hide();
            $("#btn_save_" + tbl_name).show();
            $("#btn_update_" + tbl_name).hide();
            $("#frm_" + tbl_name).trigger("reset");
            $('.selects').trigger('change');
        });
        $(document).delegate("#btn_save_" + tbl_name, "click", function(e) {
            //alert(tbl_name);
            // $("#btn_save_"+tbl_name).attr("disabled", true);
            $.post("config/all.php", $("#frm_" + tbl_name).serialize() + "&user=insert", function(data) {
            	alert(data);
                //swal({
                    // title: " Registration",
                    //text: data,
                    // icon: "success",

                //});


                setTimeout(function() {
                    if (data != 'fill the blank inputs') {
                        swal({
                            title: "warning",
                            text: data,
                            confirmButtonClass: 'btn btn-warning',
                            buttonStayling: false,

                        }, function() {
                            $("#btn_save_" + tbl_name).attr("disabled", false);
                            window.location = "redirectURL";
                        });
                    } else {
                        swal({
                            title: "insert successfully",
                            text: data,
                            confirmButtonClass: 'btn btn-success',
                            buttonStayling: false,

                        }, function() {
                            $("#btn_save_" + tbl_name).attr("disabled", false);
                            window.location = "redirectURL";
                        });

                    }


                }, 1000);
                $("#tbl_id_" + tbl_name).load(" .tbl_cls_" + tbl_name, function() {
                    $('#dt_' + tbl_name).DataTable({
                        aaSorting: [
                            [0, 'desc']
                        ]
                    });
                });
            });
            return false;
        });

        $(document).delegate("#btn_no_" + tbl_name, "click", function(e) {
            $.post("config/all.php", $("#frm_" + tbl_name).serialize(), function(data) {
                swal("", data);
                $("#tbl_id_" + tbl_name).load(" .tbl_cls_" + tbl_name, function() {
                    $('#dt_' + tbl_name).DataTable({
                        aaSorting: [
                            [0, 'desc']
                        ]
                    });
                });
            });
            return false;
        });
        $(document).delegate("#btn_update_" + tbl_name, "click", function(e) {
            //alert(tbl_name);
            $.post("config/all.php", $("#frm_" + tbl_name).serialize() + "&user=update", function(data) {
                 alert(data);
                //swal({
                    // title: " Registration",
                    //text: data,
                    // icon: "success",

                //});
                //alert("Waa la update gareeyey", data);
                $("#tbl_id_" + tbl_name).load(" .tbl_cls_" + tbl_name, function() {
                    $('#dt_' + tbl_name).DataTable({
                        aaSorting: [
                            [0, 'desc']
                        ]
                    });
                });
            });
            return false;
        });
        $(document).delegate(".btn_delete_" + tbl_name, "click", function(e) {

            $.post("config/all.php", $("#frm_" + tbl_name).serialize() + "&user=delete", function(data) {
                $("#mdl_delete_all").modal('hide');
                alert(data);
                //swal("", data);

                $("#tbl_id_" + tbl_name).load(" .tbl_cls_" + tbl_name, function() {
                    $('#dt_' + tbl_name).DataTable({
                        aaSorting: [
                            [0, 'desc']
                        ]
                    });
                });
            });
            return false;
        });
    }

    function SYD_Combo_Dia(qry, comName) {
        var httpxml;
        try {
            // Firefox, Opera 8.0+, Safari
            httpxml = new XMLHttpRequest();
        } catch (e) {
            // Internet Explorer
            try {
                httpxml = new ActiveXObject("Msxml2.XMLHTTP");
            } catch (e) {
                try {
                    httpxml = new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
                    alert("Your browser does not support AJAX!");
                    return false;
                }
            }
        }

        function stateck() {
            var combo = document.getElementById(comName);
            if (httpxml.readyState == 4) {
                var myarray = JSON.parse(httpxml.responseText);
                //  	alert(httpxml.responseText);
                for (j = combo.options.length; j > 0; j--) {
                    combo.remove(j);
                }
                for (i = 0; i < myarray.data.length; i++) {
                    var optn = document.createElement("OPTION");
                    optn.value = myarray.data[i][0].replace(/_/g, ' ');
                    optn.text = myarray.data[i][1].replace(/_/g, ' ');
                    combo.options.add(optn);
                }
            }
        } // end of function stateck
        var url = "config/dynamicCombo.php";
        url = url + "?qry=" + qry;
        url = url + "&sid=" + Math.random();
        httpxml.onreadystatechange = stateck;
        httpxml.open("GET", url, true);
        httpxml.send(null);
    }

    function SYD_Combo_load(btnclose, classcom, idcomb, combox, modal) {
        var clas = classcom.split("|");
        var id = idcomb.split("|");
        var combo = combox.split("|");
        var mdl = modal.split("|");
        var i, x;
        $('#' + btnclose).on('hidden.bs.modal', function() {
            // alert();
            for (i = 0; i < combo.length; i++) {
                $("." + clas[i]).load(" #" + id[i], function() {
                    for (x = 0; x <= i - 1; x++) {
                        if (mdl[x] == "") {
                            $("#" + combo[x]).select2();
                        } else {
                            $("#" + combo[x]).select2({
                                dropdownParent: $("#" + mdl[x])
                            });
                        }
                    }
                });
            }
        });
    }

    function SYD_TableLoad(btnclose, classcom, idcomb, tbls) {
        var clas = classcom.split("|");
        var id = idcomb.split("|");
        var tbl = tbls.split("|");
        var i, x;
        $("#" + btnclose).click(function() {
            for (i = 0; i < tbl.length; i++) {
                $("." + clas[i]).load(" #" + id[i], function() {
                    for (x = 0; x <= i - 1; x++) {
                        $("#" + tbl[x]).DataTable();
                    }
                });
            }
        });
    }

    function printData() {
        var divToPrint = document.getElementById("rpt_show_PRINT");
        newWin = window.open("");
        newWin.document.write("<style> .table th { padding-top: 12px;padding-bottom: 12px;text-align: left;background-color: blue;color: white; } </style>" + divToPrint.outerHTML);
        newWin.print();
        newWin.close();

    }

    $('#btn_prt_dt_rpt').click(function() {

        printData();
    })
</script>

<!-- All Events here -->



<!-- Include Bootstrap JS and jQuery -->
<!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        document.getElementById('txtaiplane').addEventListener('input', validateInput);

        function validateInput() {
            var inputField = document.getElementById('txtaiplane');
            var errorMsg = document.getElementById('error-msg');
            var inputValue = inputField.value;

            if (/^\d+$/.test(inputValue)) { // Check if the input is an integer
                errorMsg.style.display = 'inline';
                inputField.setCustomValidity('Please enter a string, not a number.');
            } else {
                errorMsg.style.display = 'none';
                inputField.setCustomValidity(''); // Clear the custom validation message
            }
        }

        function validateForm() {
            var inputField = document.getElementById('txtaiplane');
            if (inputField.checkValidity()) {
                //Perform the save/update operation
                alert('Form is valid and ready to submit.');
            } else {
                inputField.reportValidity();
            }
        }
    </script> -->

    <script>
        document.addEventListener("DOMContentLoaded", function() {
    // Validation for strings
    function validateString(input) {
        if (!isNaN(input.value)) {
            alert("Please enter a string.");
            input.value = "";
        }
    }

    // Validation for integers
    function validateInteger(input) {
        if (isNaN(input.value)) {
            alert("Please enter an integer.");
            input.value = "";
        }
    }

    // Validation for dates
    function validateDate(input) {
        const today = new Date();
        const inputDate = new Date(input.value);
        if (inputDate > today) {
            alert("Please enter a correct birthday .");
            input.value = "";
        }
    }

    // Attach validation to string inputs
    document.querySelectorAll('.validate-string').forEach(function(input) {
        input.addEventListener('change', function() {
            validateString(input);
        });
    });

    // Attach validation to integer inputs
    document.querySelectorAll('.validate-integer').forEach(function(input) {
        input.addEventListener('change', function() {
            validateInteger(input);
        });
    });

    // Attach validation to date inputs
    document.querySelectorAll('.validate-date').forEach(function(input) {
        input.addEventListener('change', function() {
            validateDate(input);
        });
    });

    // Attach form submission handler to validate all fields
    document.querySelectorAll('form').forEach(function(form) {
        form.addEventListener('submit', function(event) {
            let isValid = true;

            form.querySelectorAll('.validate-string').forEach(function(input) {
                if (!isNaN(input.value)) {
                    isValid = false;
                    alert("Please enter a string.");
                    input.value = "";
                }
            });

            form.querySelectorAll('.validate-integer').forEach(function(input) {
                if (isNaN(input.value)) {
                    isValid = false;
                    alert("Please enter an integer.");
                    input.value = "";
                }
            });

            form.querySelectorAll('.validate-date').forEach(function(input) {
                const today = new Date();
                const inputDate = new Date(input.value);
                if (inputDate < today) {
                    isValid = false;
                    alert("Please enter a current or future date.");
                    input.value = "";
                }
            });

            if (!isValid) {
                event.preventDefault();
            }
        });
    });
});

</script>



<script>
document.addEventListener("DOMContentLoaded", function () {
    // Function to validate number fields
    function validateNumberField(field) {
        const value = field.value.trim();
        const errorMessage = document.getElementById(`${field.id}_error_message`);
        const successMessage = document.getElementById(`${field.id}_success_message`);

        if (/^\d{8}$/.test(value)) {
            // If the input is exactly 8 digits, show the success message and hide the error message
            successMessage.textContent = "You entered: " + value;
            successMessage.style.display = "inline";
            errorMessage.style.display = "none";
            field.setCustomValidity("");
        } else {
            // If the input is not exactly 8 digits, show the error message and hide the success message
            successMessage.style.display = "none";
            errorMessage.style.display = "inline";
            field.setCustomValidity("Invalid input.");
        }
    }

    // Attach validation to all number input fields
    const numberFields = document.querySelectorAll('input[type="number"]');
    numberFields.forEach(field => {
        field.addEventListener("input", function () {
            validateNumberField(field);
        });
    });

    document.getElementById("frm_Employee").addEventListener("submit", function(event) {
        let formValid = true;
        numberFields.forEach(field => {
            validateNumberField(field);
            if (!field.checkValidity()) {
                formValid = false;
            }
        });

        if (!formValid) {
            event.preventDefault();
            alert("Please correct the errors in the form.");
        }
    });
});
</script>
