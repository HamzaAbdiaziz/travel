<script type="text/javascript">

	SYD_ALL("mdl_airsplane", "SELECT *  FROM airsplane WHERE airsplane_no=", "");

	SYD_ALL("mdl_countries", "SELECT * FROM countries WHERE country_no=", "");

	SYD_ALL("mdl_Passengers", "SELECT * FROM Passengers WHERE Passengers_no=", "");

	SYD_ALL("mdl_employee", "SELECT * FROM employee WHERE Employee_no=", "");

	SYD_ALL("mdl_flight", "SELECT * FROM flight WHERE flight_no=", "");

	SYD_ALL("mdl_accounts", "SELECT * FROM accounts WHERE accounts_no=", "");

	SYD_ALL("mdl_Ticket", "SELECT * FROM Ticket WHERE Ticket_no=", "");

	SYD_ALL("mdl_expense_payment", "SELECT * FROM expense_payment WHERE expense_payment_no=", "");



	$(".btn_tikchet_info").click(function() {
		$("#mdl_All_reports").modal("show");
		var qry = "call ticket_report_all()";
		$.post("config/SYD_Table.php", "qry=" + qry, function(data) {
			// alert(qry);
			$("#rpt_show").html(data);
		});
	});


	$(".btn_employee_all").click(function() {
		$("#mdl_All_reports").modal("show");
		var qry = "call employee_report_All()";
		$.post("config/SYD_Table.php", "qry=" + qry, function(data) {
			// alert(qry);
			$("#rpt_show").html(data);
		});
	});


	$(".btn_flight_report_all").click(function() {
		$("#mdl_All_reports").modal("show");
		var qry = "call flight_report_all()";
		$.post("config/SYD_Table.php", "qry=" + qry, function(data) {
			// alert(qry);
			$("#rpt_show").html(data);
		});
	});

	$(".btn_single_flight_reports").click(function() {
		//alert();
		$("#mdl_All_reports").modal("show");
		var qry = "call flight_report_single('" + $("#cbm_flight_print").val() + "')";
		//alert(qry);
		$.post("config/SYD_Table.php", "qry=" + qry, function(data) {
			//alert(qry);
			$("#rpt_show").html(data);
		});
	});


	$(".btn_employee_single").click(function() {
		//alert();
		$("#mdl_All_reports").modal("show");
		var qry = "call employee_report_single('" + $("#cbm_employee_print").val() + "')";
		//alert(qry);
		$.post("config/SYD_Table.php", "qry=" + qry, function(data) {
			//alert(qry);
			$("#rpt_show").html(data);
		});
	});

	$(".btn_ticke_Report_Single").click(function() {
		//alert();
		$("#mdl_All_reports").modal("show");
		var qry = "call ticket_report_single('" + $("#cbm_ticket_print").val() + "')";
		//alert(qry);
		$.post("config/SYD_Table.php", "qry=" + qry, function(data) {
			//alert(qry);
			$("#rpt_show").html(data);
		});
	});


	$(".btn_tikchet_two_dates").click(function() {
		//  alert();
		$("#mdl_All_reports").modal("show");
		var qry = "call ticket_report_btw_two_dates('" + $("#ticket_date1").val() + "','" + $("#ticket_date2").val() + "');";
		$.post("config/SYD_Table.php", "qry=" + qry, function(data) {
			// alert(qry);
			$("#rpt_show").html(data);
		});
	});





</script>