<!-- <script>

document.addEventListener('DOMContentLoaded', (event) => {
    function validateString(value) {
        return /^[a-zA-Z\s]*$/.test(value);
    }

    function validateInteger(value) {
        return /^[0-9]*$/.test(value);
    }

    function validateDate(value) {
        const inputDate = new Date(value);
        const currentDate = new Date();
        return inputDate >= currentDate;
    }

    function showValidationError(input, message) {
        const alertDiv = document.createElement('div');
        alertDiv.classList.add('alert', 'alert-danger');
        alertDiv.textContent = message;
        input.parentElement.appendChild(alertDiv);
    }

    function clearValidationErrors(form) {
        const alertDivs = form.querySelectorAll('.alert');
        alertDivs.forEach(alertDiv => alertDiv.remove());
    }

    function validateForm(event) {
        event.preventDefault();
        const form = event.target.form;
        clearValidationErrors(form);

        let isValid = true;
        const inputs = form.querySelectorAll('input');

        inputs.forEach(input => {
            if (input.classList.contains('validate-string')) {
                if (!validateString(input.value)) {
                    showValidationError(input, 'Please enter a valid string.');
                    isValid = false;
                }
            } else if (input.classList.contains('validate-integer')) {
                if (!validateInteger(input.value)) {
                    showValidationError(input, 'Please enter a valid integer.');
                    isValid = false;
                }
            } else if (input.classList.contains('validate-date')) {
                if (!validateDate(input.value)) {
                    showValidationError(input, 'Please enter a current or future date.');
                    isValid = false;
                }
            }
        });

        if (isValid) {
            form.submit();
        }
    }

    const saveButtons = document.querySelectorAll('button[type="button"]');
    saveButtons.forEach(button => {
        button.addEventListener('click', validateForm);
    });
});


</script> -->


<!-- Include Bootstrap JS and jQuery
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        document.getElementById('txtaiplane').addEventListener('input', validateInput);

        function validateInput() {
            var inputField = document.getElementById('txtaiplane');
            var errorMsg = document.getElementById('error-msg');
            var inputValue = inputField.value;

            if (/^\d+$/.test(inputValue)) { // Check if the input is an integer
                errorMsg.style.display = 'inline';
                inputField.setCustomValidity('Please enter a string, not a number.');
            } else {
                errorMsg.style.display = 'none';
                inputField.setCustomValidity(''); // Clear the custom validation message
            }
        }

        function validateForm() {
            var inputField = document.getElementById('txtaiplane');
            if (inputField.checkValidity()) {
                //Perform the save/update operation
                alert('Form is valid and ready to submit.');
            } else {
                inputField.reportValidity();
            }
        }
    </script> -->

    