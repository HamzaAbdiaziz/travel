<!-- All MDL Reports -->

<div class="modal  fade" id="mdl_All_reports" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="margin-top: 3%">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalLabel"> Report</h4>
                <button type="button" class="btn-close" style="background-color: white; cursor: pointer; position: absolute;" data-bs-dismiss="modal" aria-label="Close"></button>
                <!-- <button type="button" class="btn btn-success btn-sm" id="btn_prt_dt_rpt">PRINT</button> -->
                <button type="button" class="btn btn-primary btn-md" id="btn_prt_dt_rpt">PRINT</button>
            </div>

            <div class="modal-body">
                <div class="row">

                    <div class="col-md-12">
                        <form id="rpt_show_PRINT">
                            <div class="col-md-12">
                                <center>
                                    <img src="assets/img/travel2.webp" class="img img-fluid " style="width: 100%; height: 130px; margin-top: -2%;">
                                </center>
                            </div>
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <div id="rpt_show"></div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- All MDL Reports -->


<!-- -----------MDL DELETE------------ -->
<div style="position: absolute">
    <div class="modal fade" id="mdl_delete_all" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content" style="top: 150px;">
                <div class="model-header bg-primary p-15">
                    <h4 class="modal-title text-center" style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif; color: #fff;">
                        Delete Record</h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h6 style="font-size: 12px; text-align: center;color: primary;"><strong>Are you sure you
                                    want to delete this record?</strong></h6><br>
                            <h1 style="font-family: impact; font-size: 20px; text-align: center; color: blue; "></h1>
                        </div>
                    </div>
                    <div class="col-md-12 text-center ">
                        <button type="submit" class="btn btn-danger btn-sm btn-circle " id="yes_d_btn"><span>YES</span></button>
                        <button type="button" class="btn btn-primary btn-sm m-l-80" data-dismiss="modal"><span id="spm_deld_Faculty">NO</span></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END MDL DELETE -->



<!-- airpalne modal -->

<!-- Modal -->
<div class="modal fade" id="mdl_airsplane" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">Modal airsplane</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div id="airsplane_alert"></div>

            <div class="modal-body">
                <form id="frm_airsplane" class="">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="hidden" name="airsplane_pro" value="airsplane_pro">
                            <input type="hidden" name="airsplane_no" id="airsplane_no">
                        </div>

                        <div class="col-md-6">
                            <label for="form-label">Airpalne</label>
                            <input type="text" name="txtaiplane"  class="form-control validate-string"  id="txtaiplane" placeholder="Enter Airplane" required>

                        </div>
                    
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="btn_save_airsplane" >Save </button>
                <button type="button" class="btn btn-primary" id="btn_update_airsplane" >Update</button>
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>

            </div>
        </div>
    </div>
</div>

<!--end airpalne modal -->


<!-- countries modal -->

<!-- Modal -->
<div class="modal fade" id="mdl_countries" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">Modal countries</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div id="countries_alert"></div>

            <div class="modal-body">
                <form id="frm_countries" class="">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="hidden" name="countries_pro" value="countries_pro">
                            <input type="hidden" name="country_no" id="country_no">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Country Name</label>
                            <input type="text" name="country_name" class="form-control validate-string" id="country_name" placeholder="Enter Country Name">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">City Name </label>
                            <input type="text" name="city_name" class="form-control validate-string" id="city_name" placeholder="Enter city Name">
                        </div>

                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="btn_save_countries">Save </button>
                <button type="button" class="btn btn-primary" id="btn_update_countries">Update</button>
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>

            </div>
        </div>
    </div>
</div>

<!--end countries modal -->




<!--  Passengers modal -->

<!-- Modal -->
<div class="modal fade" id="mdl_Passengers" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">Modal Passengers</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div id="Passengers_alert"></div>

            <div class="modal-body">
                <form id="frm_Passengers" class="">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="hidden" name="Passengers_pro" value="Passengers_pro">
                            <input type="hidden" name="Passengers_no" id="Passengers_no">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Name</label>
                            <input type="text" name="Passengers_name" class="form-control validate-string" id="Passengers_name" placeholder="Enter Passengers Name">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">tell</label>
                            <input type="number" name="Passengers_tell" class="form-control validate-integer" id="Passengers_tell" placeholder="Enter tell " required>
                            <span class="error" id="Passengers_tell_error_message">Please enter exactly 8 digits.</span>
                            <span class="success" id="Passengers_tell_success_message"></span>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">sex</label>
                            <?php $coder->fillCombo("SELECT s.sex_no, s.sex_name as sex FROM sex s ORDER by sex_no", "cbm_sex_print", "Select sex"); ?>
                        </div>


                          <div class="col-md-6 mt-2">
                            <label for="form-label">passport</label>
                            <input type="number" name="Passengers_passport" class="form-control validate-integer" id="Passengers_passport" placeholder="Enter passport " pattern="\d{8}" title="Enter exactly 8 digits">
                        </div>


                          <div class="col-md-6 mt-2">
                            <label for="form-label">Email</label>
                            <input type="Email" name="Passengers_Email" class="form-control validate-string" id="Passengers_Email" placeholder="Enter Email ">
                        </div>


                          <div class="col-md-6 mt-2">
                            <label for="form-label">birth_date</label>
                            <input type="date" name="Passengers_birth_date" class="form-control validate-date" id="Passengers_birth_date" placeholder="Enter date ">
                        </div>




                        
                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="btn_save_Passengers">Save </button>
                <button type="button" class="btn btn-primary" id="btn_update_Passengers">Update</button>
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>

            </div>
        </div>
    </div>
</div>

<!--end  Passengers modal -->

<!--  employee modal -->

<!-- Modal -->
<div class="modal fade" id="mdl_employee" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">Modal employee</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div id="employee_alert"></div>

            <div class="modal-body">
                <form id="frm_employee" class="">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="hidden" name="employee_pro" value="employee_pro">
                            <input type="hidden" name="Employee_no" id="Employee_no">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Name</label>
                            <input type="text" name="employee_name" class="form-control validate-string" id="employee_name" placeholder="Enter employee Name">
                        </div>

                        
                        <div class="col-md-6 mt-2">
                            <label for="form-label">tell</label>
                            <input type="number" name="employee_tell" class="form-control validate-integer" id="employee_tell"  placeholder="Enter tell " required>
                            <span class="error" id="employee_tell_error_message">Please enter exactly 8 digits.</span>
                            <span class="success" id="employee_tell_success_message"></span>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">sex</label>
                            <?php $coder->fillCombo("SELECT s.sex_no, s.sex_name as sex FROM sex s ORDER by sex_no ", "cbm_sex_print", "Select sex"); ?>
                        </div>


                          <div class="col-md-6 mt-2">
                            <label for="form-label">location_name</label>
                            <input type="text" name="location_name" class="form-control validate-string" id="location_name" placeholder="Enter location_name ">
                        </div>


                          <div class="col-md-6 mt-2">
                            <label for="form-label">salary</label>
                            <input type="number" name="salary" class="form-control validate-integer" id="salary" placeholder="Enter salary ">
                        </div>





                        
                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="btn_save_employee">Save </button>
                <button type="button" class="btn btn-primary" id="btn_update_employee">Update</button>
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>

            </div>
        </div>
    </div>
</div>

<!--end  Passengers modal -->





<!-- flight modal -->

<!-- Modal -->
<div class="modal fade" id="mdl_flight" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">Flight Modal</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div id="flight_alert"></div>

            <div class="modal-body">
                <form id="frm_flight" class="">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="hidden" name="flight_pro" value="flight_pro">
                            <input type="hidden" name="flight_no" id="flight_no">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Airplane</label>
                            <?php $coder->fillCombo("SELECT a.airsplane_no,a.airsplane_name FROM airsplane a order by airsplane_no ", "cbm_flight_airlane_print", "Select Airplane"); ?>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">From Country</label>
                            <?php $coder->fillCombo("SELECT c1.country_no, concat(c1.country_name) from_location FROM countries c1 order by c1.country_no  ", "cbm_Fromlocation_print", "Select From Location"); ?>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">To Country</label>
                            <?php $coder->fillCombo("SELECT c2.country_no, concat(c2.country_name) to_location FROM countries c2 order by c2.country_no ", "cbm_Tolocation_print", "Select To Location"); ?>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Days</label>
                            <?php $coder->fillCombo("SELECT d.day_no,d.day_name FROM day d order by day_no ", "cbm_flightDays_print", "Select Days"); ?>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Time In </label>
                            <input type="time" name="txt_time1" class="form-control" id="txt_time1" placeholder="Enter city Name">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Flight Time</label>
                            <input type="time" name="txt_flight_time" class="form-control" id="txt_flight_time" placeholder="Enter Fli Name">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Price</label>
                            <input type="number" name="txt_flight_price" class="form-control validate-integer" id="txt_flight_price" placeholder="Enter Price">
                        </div>

                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="btn_save_flight">Save </button>
                <button type="button" class="btn btn-primary" id="btn_update_flight">Update</button>
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>

            </div>
        </div>
    </div>
</div>

<!--end flight modal -->









<!--  accounts modal -->

<!-- Modal -->
<div class="modal fade" id="mdl_accounts" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">Modal accounts</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div id="accounts_alert"></div>

            <div class="modal-body">
                <form id="frm_accounts" class="">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="hidden" name="accounts_pro" value="accounts_pro">
                            <input type="hidden" name="accounts_no" id="accounts_no">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">accounts Name</label>
                            <input type="text" name="accounts_name" class="form-control validate-string" id="accounts_name" placeholder="Enter accounts Name">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">instituion</label>
                            <input type="text" name="instituion_s" class="form-control validate-string" id="instituion_s" placeholder="Enter instituion ">
                        </div>

                          <div class="col-md-6 mt-2">
                            <label for="form-label">balance</label>
                            <input type="number" name="balance_b" class="form-control validate-integer" id="balance_b" placeholder="Enter balance ">
                        </div>
   
                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="btn_save_accounts">Save </button>
                <button type="button" class="btn btn-primary" id="btn_update_accounts">Update</button>
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>

            </div>
        </div>
    </div>
</div>

<!--end  accounts modal -->





<!-- Ticket modal -->

<!-- Modal -->
<div class="modal fade" id="mdl_Ticket" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">Ticket Modal</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div id="Ticket_alert"></div>

            <div class="modal-body">
                <form id="frm_Ticket" class="">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="hidden" name="Ticket_pro" value="Ticket_pro">
                            <input type="hidden" name="Ticket_no" id="Ticket_no">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Passengers</label>
                            <?php $coder->fillCombo("SELECT Passengers_no ,name FROM passengers order by Passengers_no ", "cbm_Passengers_print", "Select Passsengers"); ?>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">flight</label>
                            <?php $coder->fillCombo("SELECT flight_no, flight_time from flight order by flight_no", "cbm_flights_print", "Select flightss"); ?>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Amount</label>
                            <input type="number" name="txt_Amount" class="form-control validate-integer" id="txt_Amount" placeholder="Enter Fli Name">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Date</label>
                            <input type="date" name="txt_Ticket_date" class="form-control validate-date" id="txt_Ticket_date" placeholder="Enter Fli Name">
                        </div>>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Account</label>
                            <?php $coder->fillCombo("SELECT accounts_no, concat(accounts_name) Accounts FROM accounts order by accounts_no", "cbm_Accounts_print", "Select Accounts"); ?>
                        </div>



                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="btn_save_Ticket">Save </button>
                <button type="button" class="btn btn-primary" id="btn_update_Ticket">Update</button>
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>

            </div>
        </div>
    </div>
</div>

<!--end Ticket modal -->



<!-- expense_payment modal -->

<!-- Modal -->
<div class="modal fade" id="mdl_expense_payment" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">expense_payment Modal</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div id="expense_payment_alert"></div>

            <div class="modal-body">
                <form id="frm_expense_payment" class="">
                    <div class="row">
                        <div class="col-md-12">
                            <input type="hidden" name="expense_payment_pro" value="expense_payment_pro">
                            <input type="hidden" name="expense_payment_no" id="expense_payment_no">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Employee</label>
                            <?php $coder->fillCombo("SELECT Employee_no, name FROM employee  ", "cbm_employees_print", "Select employees"); ?>
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">expense_type</label>
                            <input type="text" name="txt_expense_type" class="form-control validate-string" id="txt_expense_type" placeholder="Enter expense_type">
                        </div>>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Amount</label>
                            <input type="number" name="txt_Amount" class="form-control validate-integer" id="txt_Amount" placeholder="Enter Fli Name">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Date</label>
                            <input type="date" name="txt_expense_date" class="form-control validate-date" id="txt_expense_date" placeholder="Enter Fli Name">
                        </div>

                        <div class="col-md-6 mt-2">
                            <label for="form-label">Account</label>
                            <?php $coder->fillCombo("SELECT accounts_no, concat(accounts_name) Accounts FROM accounts order by accounts_no", "cbm_Accounts_print", "Select Accounts"); ?>
                        </div>



                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="btn_save_expense_payment">Save </button>
                <button type="button" class="btn btn-primary" id="btn_update_expense_payment">Update</button>
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                    Close
                </button>

            </div>
        </div>
    </div>
</div>

<!--end Ticket modal -->