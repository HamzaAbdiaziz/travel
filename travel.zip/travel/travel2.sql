-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2024 at 06:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travel2`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `accounts_pro` (IN `num` INT, IN `accounts_name_sp` VARCHAR(40), IN `instituion_sp` VARCHAR(40), IN `balance_sp` DOUBLE, IN `oper` VARCHAR(30))   begin
case
WHEN (accounts_name_sp='') THEN
SELECT 'meelaha banaan soo buuxi' as msg;
when oper='insert' then
if exists(select * from accounts where  accounts_name_sp=accounts_name and instituion_sp=instituion and balance_sp=balance ) then
select concat( accounts_name,instituion, balance,' already exists') as msg;
else 
insert into accounts values(null, accounts_name_sp,instituion_sp,balance_sp);
select 'inserted success' as msg;
end if;
when oper='update' then
if exists(select * from accounts where  accounts_no=num) then
update accounts set  accounts_name=accounts_name_sp, instituion=instituion_sp, balance=balance_sp where accounts_no=num;
select 'updated success ' as msg;
else
select concat(num, ' is  not eixist') as msg;
end if;
when oper='delete' then
if exists(select * from accounts where  accounts_no=num) then
delete from accounts where  accounts_no=num;
select 'deleted success' as msg;
else
select concat(num, ' is not exist ') as msg;
end if;
end case;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `accounts_view` ()   BEGIN
SELECT  accounts_no, accounts_name,instituion,balance from accounts;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `airsplane_pro` (IN `num` INT, IN `airsplane_name_sp` VARCHAR(40), IN `oper` VARCHAR(30))   begin
case
WHEN (airsplane_name_sp='') THEN
SELECT 'meelaha banaan soo buuxi' as msg;
when oper='insert' then
if exists(select * from airsplane where airsplane_name_sp=airsplane_name  ) then
select concat(airsplane_name,' already exists') as msg;
else 
insert into airsplane values(null,airsplane_name_sp);
select 'inserted success' as msg;
end if;
when oper='update' then
if exists(select * from airsplane where airsplane_no=num) then
update airsplane set airsplane_name=airsplane_name_sp  where airsplane_no=num;
select 'updated success ' as msg;
else
select concat(num, ' is  not eixist') as msg;
end if;
when oper='delete' then
if exists(select * from airsplane where airsplane_no=num) then
delete from airsplane where airsplane_no=num;
select 'deleted success' as msg;
else	
select concat(num, ' is not exist ') as msg;
end if;
end case;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `airsplane_view` ()   BEGIN
SELECT airsplane_no,airsplane_name from airsplane;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `countries_pro` (IN `num` INT, IN `country_name_sp` VARCHAR(40), IN `city_name_sp` VARCHAR(40), IN `oper` VARCHAR(30))   begin
case
WHEN (country_name_sp='') THEN
SELECT 'meelaha banaan soo buuxi' as msg;
when oper='insert' then
if exists(select * from countries where country_name_sp=country_name and city_name=city_name_sp ) then
select concat(country_name,' already exists') as msg;
else 
insert into countries values(null,country_name_sp,city_name_sp);
select 'inserted success' as msg;
end if;
when oper='update' then
if exists(select * from countries where country_no=num) then
update countries set country_name=country_name_sp, city_name=city_name_sp where country_no=num;
select 'updated success ' as msg;
else
select concat(num, ' is  not eixist') as msg;
end if;
when oper='delete' then
if exists(select * from countries where country_no=num) then
delete from countries where country_no=num;
select 'deleted success' as msg;
else	
select concat(num, ' is not exist ') as msg;
end if;
end case;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `countries_view` ()   BEGIN
SELECT country_no,country_name,city_name from countries;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `day_pro` (IN `num` INT, IN `day_name_sp` VARCHAR(40), IN `oper` VARCHAR(30))   begin
case
when oper='insert' then
if exists(select * from day where day_name_sp=day_name ) then
select concat(day_name,' already exists') as msg;
else 
insert into day values(null,day_name_sp);
select 'inserted success' as msg;
end if;
when oper='update' then
if exists(select * from day where day_no=num) then
update day set day_name=day_name_sp where day_no=num;
select 'updated success ' as msg;
else
select concat(num, ' is  not eixist') as msg;
end if;
when oper='delete' then
if exists(select * from day where day_no=num) then
delete from day where day_no=num;
select 'deleted success' as msg;
else	
select concat(num, ' is not exist ') as msg;
end if;
end case;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `employee_pro` (IN `num` INT, IN `name_sp` VARCHAR(40), IN `tell_sp` INT, IN `sex_sp` INT, IN `location_name_sp` VARCHAR(40), IN `salary_sp` INT, IN `oper` VARCHAR(30))   begin
case
WHEN (name_sp='') THEN
SELECT 'meelaha banaan soo buuxi' as msg;
when oper='insert' then
if exists(select * from employee where name_sp=name and tell_sp=tell and sex_sp=sex and location_name=location_name_sp and salary=salary_sp  ) then
select concat( name,' already exists') as msg;
else 
insert into employee values(null, name_sp,tell_sp,sex_sp, location_name_sp, salary_sp);
select 'inserted success' as msg;
end if;
when oper='update' then
if exists(select * from employee where  Employee_no=num) then
update employee set  name=name_sp, tell=tell_sp, sex=sex_sp, location_name_sp=location_name, salary_sp=salary where Employee_no=num;
select 'updated success ' as msg;
else
select concat(num, ' is  not eixist') as msg;
end if;
when oper='delete' then
if exists(select * from employee where  Employee_no=num) then
delete from employee where  Employee_no=num;
select 'deleted success' as msg;
else
select concat(num, ' is not exist ') as msg;
end if;
end case;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `employee_report_single` (IN `num` INT)   BEGIN
SELECT Employee_no, name, tell, sex, location_name, salary FROM employee WHERE Employee_no=num;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `employee_view` ()   BEGIN
SELECT  Employee_no, name,tell,sex_name as sex, location_name, salary from employee e, sex s WHERE e.sex=s.sex_no;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `expense_payment_pro` (IN `num` INT, IN `Employee_no_sp` INT, IN `expense_type_sp` VARCHAR(40), IN `amount_sp` DOUBLE, IN `expense_payment_date_sp` DATE, IN `accounts_no_sp` INT, IN `oper` VARCHAR(30))   begin
case
WHEN (Employee_no_sp='') THEN
SELECT 'meelaha banaan soo buuxi' as msg;
when oper='insert' then
if exists(select * from expense_payment where Employee_no_sp=Employee_no and expense_type_sp=expense_type  and amount_sp=amount and expense_payment_date_sp=expense_payment_date and accounts_no_sp=accounts_no   ) then
select concat( expense_type ,' already exists') as msg;
else 
insert into expense_payment values(null, Employee_no_sp, expense_type_sp,amount_sp, expense_payment_date_sp ,accounts_no_sp);
select 'inserted success' as msg;
end if;
when oper='update' then
if exists(select * from expense_payment where  expense_payment_no=num) then
update expense_payment set  Employee_no_sp=Employee_no, expense_type=expense_type_sp, amount=amount_sp, expense_payment_date_sp=expense_payment_date  , accounts_no=accounts_no_sp where expense_payment_no=num;
select 'updated success ' as msg;
else
select concat(num, ' is  not eixist') as msg;
end if;
when oper='delete' then
if exists(select * from expense_payment where  expense_payment_no=num) then
delete from expense_payment where  expense_payment_no=num;
select 'deleted success' as msg;
else
select concat(num, ' is not exist ') as msg;
end if;
end case;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `expense_payment_view` ()   BEGIN
SELECT  ex.expense_payment_no ID, emp.name as Name , expense_type Expense_type ,amount Amount, expense_payment_date Taariikhda, a.accounts_name AS Account from expense_payment ex, employee emp , accounts a WHERE  emp.Employee_no=ex.Employee_no and a.accounts_no=ex.accounts_no;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `flight_pro` (IN `num` INT, IN `airsplane_no_sp` INT, IN `from_location_no_sp` INT, IN `to_location_sp` INT, IN `day_sp` INT, IN `time_in_sp` TIME, IN `flight_time_sp` TIME, IN `price_sp` DOUBLE, IN `oper` VARCHAR(30))   begin 
case
WHEN (airsplane_no_sp='') THEN
SELECT 'meelaha banaan soo buuxi' as msg;
when oper='insert' then
if exists(select * from flight where  airsplane_no_sp=airsplane_no and from_location_no_sp=from_location_no and to_location_sp=to_location_no and  day_sp= day and  time_in=time_in_sp and flight_time_sp=flight_time and price=price_sp ) then
select concat( flight_no,' already exists') as msg;
else 
insert into flight values(null, airsplane_no_sp,from_location_no_sp,to_location_sp, day_sp,  time_in_sp, flight_time_sp, price_sp);
select 'inserted success' as msg;
end if;
when oper='update' then
if exists(select * from flight where  flight_no=num) then
update flight set  airsplane_no=airsplane_no_sp, from_location_no=from_location_no_sp, to_location_no=to_location_sp,  day=day_sp,  time_in=time_in_sp, flight_time=flight_time_sp, price=price_sp where flight_no=num;
select 'updated success ' as msg;
else
select concat(num, ' is  not eixist') as msg;
end if;
when oper='delete' then
if exists(select * from flight where  flight_no=num) then
delete from flight where  flight_no=num;
select 'deleted success' as msg;
else
select concat(num, ' is not exist ') as msg;
end if;
end case;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `flight_report_all` ()   BEGIN
SELECT  f.flight_no ID, a.airsplane_name 'Airplane Name',c1.country_name 'From Location',c2.country_name 'To  Location', d.day_name 'Day Name',  f.time_in 'Time In', f.flight_time 'Flight Time', f.price Price from flight f, countries c1, countries c2, day d, airsplane a WHERE f.airsplane_no=a.airsplane_no AND f.from_location_no=c1.country_no AND f.to_location_no=c2.country_no AND f.day=d.day_no;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `flight_report_single` (IN `num` INT)   BEGIN
SELECT  f.flight_no ID, a.airsplane_name 'Airplane Name',c1.country_name 'From Location',c2.country_name 'To  Location', d.day_name 'Day Name',  f.time_in 'Time In', f.flight_time 'Flight Time', f.price Price from flight f, countries c1, countries c2, day d, airsplane a WHERE f.airsplane_no=a.airsplane_no AND f.from_location_no=c1.country_no AND f.to_location_no=c2.country_no AND f.day=d.day_no and flight_no=num;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `flight_view` ()   BEGIN

SELECT  f.flight_no ID, a.airsplane_name 'Airplane Name',c1.country_name 'From Location',c2.country_name 'To  Location', d.day_name 'Day Name',  f.time_in 'Time In', f.flight_time 'Flight Time', f.price Price from flight f, countries c1, countries c2, day d, airsplane a WHERE f.airsplane_no=a.airsplane_no AND f.from_location_no=c1.country_no AND f.to_location_no=c2.country_no AND f.day=d.day_no;

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Passengers_pro` (IN `num` INT, IN `name_sp` VARCHAR(40), IN `tell_sp` INT, IN `sex_sp` INT, IN `passport_sp` INT, IN `email_sp` VARCHAR(40), IN `birth_date_sp` DATE, IN `oper` VARCHAR(30))   begin
case
WHEN (name_sp='') THEN
SELECT 'meelaha banaan soo buuxi' as msg;
when oper='insert' then
if exists(select * from Passengers where name_sp=name and tell=tell_sp and sex=sex_sp and passport=passport_sp and email=email_sp and birth_date=birth_date_sp ) then
select concat(name,' already exists') as msg;
else 
insert into Passengers values(null,name_sp,tell_sp, sex_sp, passport_sp, email_sp, birth_date_sp);
select 'inserted success' as msg;
end if;
when oper='update' then
if exists(select * from Passengers where Passengers_no=num) then
update Passengers set name=name_sp, tell=tell_sp, sex=sex_sp, passport=passport_sp, email=email_sp, birth_date=birth_date_sp where Passengers_no=num;
select 'updated success ' as msg;
else
select concat(num, ' is  not eixist') as msg;
end if;
when oper='delete' then
if exists(select * from Passengers where Passengers_no=num) then
delete from Passengers where Passengers_no=num;
select 'deleted success' as msg;
else	
select concat(num, ' is not exist ') as msg;
end if;
end case;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Passengers_view` ()   BEGIN
SELECT Passengers_no,name, tell, sex_name as sex, passport, email, birth_date from Passengers p, sex s WHERE p.sex=s.sex_no;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sex_pro` (IN `num` INT, IN `sex_name_sp` VARCHAR(40), IN `oper` VARCHAR(30))   begin
case
when oper='insert' then
if exists(select * from sex where sex_name_sp=sex_name ) then
select concat(sex_name,' already exists') as msg;
else 
insert into sex values(null,sex_name_sp);
select 'inserted success' as msg;
end if;
when oper='update' then
if exists(select * from sex where sex_no=num) then
update sex set sex_name=sex_name_sp where sex_no=num;
select 'updated success ' as msg;
else
select concat(num, ' is  not eixist') as msg;
end if;
when oper='delete' then
if exists(select * from sex where sex_no=num) then
delete from sex where sex_no=num;
select 'deleted success' as msg;
else	
select concat(num, ' is not exist ') as msg;
end if;
end case;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Ticket_pro` (IN `num` INT, IN `Passengers_no_sp` INT, IN `flight_no_sp` INT, IN `amount_sp` DOUBLE, IN `Ticket_date_sp` DATE, IN `accounts_no_sp` INT, IN `oper` VARCHAR(30))   begin
case
WHEN (Passengers_no_sp='') THEN
SELECT 'meelaha banaan soo buuxi' as msg;
when oper='insert' then
if exists(select * from Ticket where  Passengers_no_sp=Passengers_no and flight_no_sp=flight_no and amount_sp=amount and Ticket_date_sp=Ticket_date and accounts_no_sp=accounts_no  ) then
select concat( Ticket_date,' already exists') as msg;
else 
insert into Ticket values(null, Passengers_no_sp,flight_no_sp,amount_sp, Ticket_date_sp, accounts_no_sp);
select 'inserted success' as msg;
end if;
when oper='update' then
if exists(select * from Ticket where  Ticket_no=num) then
update Ticket set  Passengers_no=Passengers_no_sp, flight_no=flight_no_sp, amount=amount_sp, Ticket_date=Ticket_date_sp, accounts_no=accounts_no_sp where Ticket_no=num;
select 'updated success ' as msg;
else
select concat(num, ' is  not eixist') as msg;
end if;
when oper='delete' then
if exists(select * from Ticket where  Ticket_no=num) then
delete from Ticket where  Ticket_no=num;
select 'deleted success' as msg;
else
select concat(num, ' is not exist ') as msg;
end if;
end case;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ticket_report_all` ()   BEGIN
SELECT  t.Ticket_no ID, p.name AS Name,a.airsplane_name Airsplane_name,c1.city_name From_location , c2.city_name To_location ,d.day_name AS Days , f1.Time_in ,f1.flight_time Flight_time , amount Amount, accounts_name Account_name, Ticket_date Taariikh from 
Ticket t ,passengers p, airsplane a, flight f1,  countries c1, countries c2, day d , accounts ac where p.Passengers_no=t.Passengers_no and f1.airsplane_no=a.airsplane_no and c1.country_no=f1.from_location_no and   c2.country_no=f1.to_location_no and d.day_no=f1.day  and ac.accounts_no=t.accounts_no and f1.flight_no=t.flight_no ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ticket_report_btw_two_dates` (IN `d1` DATE, `d2` DATE)   BEGIN
SELECT  t.Ticket_no ID, p.name AS Name,a.airsplane_name Airsplane_name,c1.city_name From_location , c2.city_name To_location ,d.day_name AS Days , f1.Time_in ,f1.flight_time Flight_time , amount Amount, accounts_name Account_name, Ticket_date Taariikh from 
Ticket t ,passengers p, airsplane a, flight f1,  countries c1, countries c2, day d , accounts ac where p.Passengers_no=t.Passengers_no and f1.airsplane_no=a.airsplane_no and c1.country_no=f1.from_location_no and   c2.country_no=f1.to_location_no and d.day_no=f1.day  and ac.accounts_no=t.accounts_no and f1.flight_no=t.flight_no ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ticket_report_single` (IN `num` INT)   BEGIN
SELECT  t.Ticket_no ID, p.name AS Name,a.airsplane_name Airsplane_name,c1.city_name From_location , c2.city_name To_location ,d.day_name AS Days , f1.Time_in ,f1.flight_time Flight_time , amount Amount, accounts_name Account_name, Ticket_date Taariikh from 
Ticket t ,passengers p, airsplane a, flight f1,  countries c1, countries c2, day d , accounts ac where p.Passengers_no=t.Passengers_no and f1.airsplane_no=a.airsplane_no and c1.country_no=f1.from_location_no and   c2.country_no=f1.to_location_no and d.day_no=f1.day  and ac.accounts_no=t.accounts_no and f1.flight_no=t.flight_no and Ticket_no=num ;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Ticket_view` ()   BEGIN
SELECT  t.Ticket_no ID, p.name as Name ,amount Amount, fl.flight_time Flight_time,  Ticket_date Taariikhda, a.accounts_name Acounnt from Ticket t, passengers p, accounts a, flight fl where t.Passengers_no=p.Passengers_no and fl.flight_no=t.flight_no and a.accounts_no=t.accounts_no;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `users_proc` (IN `user_names` VARCHAR(40), IN `passwords` INT, IN `user_type` ENUM('Admin','user'), IN `email` VARCHAR(40), IN `lastPasswords` INT, IN `oper` VARCHAR(40), IN `users_no` INT)   BEGIN
CASE
when oper='update' THEN
if EXISTS(SELECT * from users WHERE user_no=users_no) THEN
UPDATE users set user_name=user_names, password=passwords, user_type=user_type,  Email=email, lastPassword=lastPasswords WHERE user_no=users_no;
SELECT 'updated succes' as msg;
else
select concat(users_no,' this users is not exist') as msg;
end if;
WHEN oper='delete ' THEN
if EXISTS(SELECT * from users WHERE user_no=users_no) THEN
DELETE from users WHERE user_no=users_no;
SELECT 'deleted succes' as msg;
else
select concat(users_no,' this users is not exist') as msg;
end if;

WHEN oper='insert' THEN
if EXISTS(SELECT user_name FROM users WHERE user_name=user_names) THEN
SELECT concat(user_names, 'Already exist') as msg;
else
INSERT INTO users VALUES(null, user_names, passwords, user_type ,email, lastPasswords);
SELECT 'usered success' as msg;
END if;
END CASE;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `accounts_no` int(11) NOT NULL,
  `accounts_name` varchar(40) NOT NULL,
  `instituion` varchar(40) NOT NULL,
  `balance` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`accounts_no`, `accounts_name`, `instituion`, `balance`) VALUES
(1, 'salaam banki', 'hormuud', 300),
(2, 'IBS banki', 'hormuud', 200),
(3, 'Amal banki', 'hormuud', 260);

-- --------------------------------------------------------

--
-- Table structure for table `airsplane`
--

CREATE TABLE `airsplane` (
  `airsplane_no` int(11) NOT NULL,
  `airsplane_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `airsplane`
--

INSERT INTO `airsplane` (`airsplane_no`, `airsplane_name`) VALUES
(1, 'daalo'),
(2, 'Supper Express'),
(3, 'Turki travel'),
(4, 'saacid Travel');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `country_no` int(11) NOT NULL,
  `country_name` varchar(40) NOT NULL,
  `city_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`country_no`, `country_name`, `city_name`) VALUES
(1, 'somalia', 'mogadisho'),
(2, 'kenya', 'Narobia'),
(3, 'Turkey', 'Istanbol');

-- --------------------------------------------------------

--
-- Table structure for table `day`
--

CREATE TABLE `day` (
  `day_no` int(11) NOT NULL,
  `day_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `day`
--

INSERT INTO `day` (`day_no`, `day_name`) VALUES
(1, 'saturday'),
(2, 'sunday'),
(3, 'monday'),
(4, 'tuesday'),
(5, 'wednesday'),
(6, 'Thursday');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Employee_no` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `tell` int(11) NOT NULL,
  `sex` int(11) NOT NULL,
  `location_name` varchar(40) NOT NULL,
  `salary` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Employee_no`, `name`, `tell`, `sex`, `location_name`, `salary`) VALUES
(1, 'fuaad', 34567867, 1, 'hodan', 100),
(2, 'yaasir', 34567897, 1, 'afgooye', 100),
(3, 'fadumo', 45678945, 2, 'waaberi', 110);

-- --------------------------------------------------------

--
-- Table structure for table `expense_payment`
--

CREATE TABLE `expense_payment` (
  `expense_payment_no` int(11) NOT NULL,
  `Employee_no` int(11) NOT NULL,
  `expense_type` varchar(40) NOT NULL,
  `amount` double NOT NULL,
  `expense_payment_date` date NOT NULL,
  `accounts_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expense_payment`
--

INSERT INTO `expense_payment` (`expense_payment_no`, `Employee_no`, `expense_type`, `amount`, `expense_payment_date`, `accounts_no`) VALUES
(1, 1, 'mishaar', 40, '2024-06-22', 1),
(2, 2, 'mishaar', 100, '2024-06-22', 2);

--
-- Triggers `expense_payment`
--
DELIMITER $$
CREATE TRIGGER `expense_payment_recieve` AFTER INSERT ON `expense_payment` FOR EACH ROW BEGIN
update accounts set accounts.balance=accounts.balance-new.amount WHERE accounts.accounts_no=new.Employee_no;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `flight`
--

CREATE TABLE `flight` (
  `flight_no` int(11) NOT NULL,
  `airsplane_no` int(11) NOT NULL,
  `from_location_no` int(11) NOT NULL,
  `to_location_no` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `time_in` time NOT NULL,
  `flight_time` time NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `flight`
--

INSERT INTO `flight` (`flight_no`, `airsplane_no`, `from_location_no`, `to_location_no`, `day`, `time_in`, `flight_time`, `price`) VALUES
(1, 1, 1, 2, 1, '03:18:00', '04:18:00', 140),
(2, 2, 1, 3, 2, '09:01:00', '13:02:00', 150),
(3, 3, 2, 1, 3, '09:12:00', '22:12:00', 125);

-- --------------------------------------------------------

--
-- Table structure for table `passengers`
--

CREATE TABLE `passengers` (
  `Passengers_no` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `tell` int(11) NOT NULL,
  `sex` int(11) NOT NULL,
  `passport` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `birth_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `passengers`
--

INSERT INTO `passengers` (`Passengers_no`, `name`, `tell`, `sex`, `passport`, `email`, `birth_date`) VALUES
(1, 'hamza', 34567876, 1, 45678, 'hamza@gmail.com', '2003-09-08'),
(2, 'camaar', 34567987, 1, 3464, 'camaar@gmail.com', '2024-06-22'),
(3, 'muna', 87235678, 2, 34567, 'muna44@gmail.com', '2024-06-28');

-- --------------------------------------------------------

--
-- Table structure for table `sex`
--

CREATE TABLE `sex` (
  `sex_no` int(11) NOT NULL,
  `sex_name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sex`
--

INSERT INTO `sex` (`sex_no`, `sex_name`) VALUES
(1, 'male'),
(2, 'female');

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `Ticket_no` int(11) NOT NULL,
  `Passengers_no` int(11) NOT NULL,
  `flight_no` int(11) NOT NULL,
  `amount` double NOT NULL,
  `Ticket_date` date NOT NULL,
  `accounts_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`Ticket_no`, `Passengers_no`, `flight_no`, `amount`, `Ticket_date`, `accounts_no`) VALUES
(1, 1, 1, 140, '2024-01-02', 1),
(2, 2, 2, 100, '2024-06-28', 2),
(3, 3, 3, 110, '2024-06-22', 3);

--
-- Triggers `ticket`
--
DELIMITER $$
CREATE TRIGGER `ticket_recieve` AFTER INSERT ON `ticket` FOR EACH ROW BEGIN
update accounts set accounts.balance=accounts.balance+new.amount WHERE accounts.accounts_no=new.Passengers_no;
end
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_no` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` int(11) NOT NULL,
  `user_type` enum('Admin','user') NOT NULL,
  `Email` varchar(40) DEFAULT NULL,
  `lastPassword` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_no`, `user_name`, `password`, `user_type`, `Email`, `lastPassword`) VALUES
(1, 'hamza', 567, 'Admin', 'hamza@gmail.com', 444);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`accounts_no`),
  ADD KEY `index_acc` (`accounts_no`,`accounts_name`,`instituion`,`balance`);

--
-- Indexes for table `airsplane`
--
ALTER TABLE `airsplane`
  ADD PRIMARY KEY (`airsplane_no`),
  ADD KEY `index_sup` (`airsplane_no`,`airsplane_name`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`country_no`),
  ADD KEY `index_sup` (`country_no`,`country_name`,`city_name`);

--
-- Indexes for table `day`
--
ALTER TABLE `day`
  ADD PRIMARY KEY (`day_no`),
  ADD KEY `index_sup` (`day_no`,`day_name`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Employee_no`),
  ADD KEY `index_acc` (`Employee_no`,`name`,`tell`,`sex`,`location_name`),
  ADD KEY `cons_fk_employe` (`sex`);

--
-- Indexes for table `expense_payment`
--
ALTER TABLE `expense_payment`
  ADD PRIMARY KEY (`expense_payment_no`),
  ADD KEY `index_acc` (`expense_payment_no`,`expense_type`,`amount`),
  ADD KEY `cons_fk_emp1` (`accounts_no`),
  ADD KEY `cons_fk_emp2` (`Employee_no`);

--
-- Indexes for table `flight`
--
ALTER TABLE `flight`
  ADD PRIMARY KEY (`flight_no`),
  ADD KEY `index_acc` (`flight_no`,`day`,`time_in`,`flight_time`),
  ADD KEY `cons_fk_air1` (`airsplane_no`),
  ADD KEY `cons_fk_con2` (`from_location_no`),
  ADD KEY `cons_fk_con3` (`to_location_no`),
  ADD KEY `cons_fk_flno` (`day`);

--
-- Indexes for table `passengers`
--
ALTER TABLE `passengers`
  ADD PRIMARY KEY (`Passengers_no`),
  ADD KEY `index_sup` (`Passengers_no`,`name`,`email`),
  ADD KEY `cons_fk_passengers` (`sex`);

--
-- Indexes for table `sex`
--
ALTER TABLE `sex`
  ADD PRIMARY KEY (`sex_no`),
  ADD KEY `index_sup` (`sex_no`,`sex_name`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`Ticket_no`),
  ADD KEY `index_acc` (`Ticket_no`,`amount`,`Ticket_date`),
  ADD KEY `cons_fk_p1` (`Passengers_no`),
  ADD KEY `cons_fk_p2` (`flight_no`),
  ADD KEY `cons_fk_p3` (`accounts_no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `accounts_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `airsplane`
--
ALTER TABLE `airsplane`
  MODIFY `airsplane_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `country_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `day`
--
ALTER TABLE `day`
  MODIFY `day_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `Employee_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `expense_payment`
--
ALTER TABLE `expense_payment`
  MODIFY `expense_payment_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `flight`
--
ALTER TABLE `flight`
  MODIFY `flight_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `passengers`
--
ALTER TABLE `passengers`
  MODIFY `Passengers_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sex`
--
ALTER TABLE `sex`
  MODIFY `sex_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `Ticket_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `cons_fk_employe` FOREIGN KEY (`sex`) REFERENCES `sex` (`sex_no`) ON UPDATE CASCADE;

--
-- Constraints for table `expense_payment`
--
ALTER TABLE `expense_payment`
  ADD CONSTRAINT `cons_fk_emp1` FOREIGN KEY (`accounts_no`) REFERENCES `accounts` (`accounts_no`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cons_fk_emp2` FOREIGN KEY (`Employee_no`) REFERENCES `employee` (`Employee_no`) ON UPDATE CASCADE;

--
-- Constraints for table `flight`
--
ALTER TABLE `flight`
  ADD CONSTRAINT `cons_fk_air1` FOREIGN KEY (`airsplane_no`) REFERENCES `airsplane` (`airsplane_no`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cons_fk_con2` FOREIGN KEY (`from_location_no`) REFERENCES `countries` (`country_no`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cons_fk_con3` FOREIGN KEY (`to_location_no`) REFERENCES `countries` (`country_no`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cons_fk_flno` FOREIGN KEY (`day`) REFERENCES `day` (`day_no`) ON UPDATE CASCADE;

--
-- Constraints for table `passengers`
--
ALTER TABLE `passengers`
  ADD CONSTRAINT `cons_fk_passengers` FOREIGN KEY (`sex`) REFERENCES `sex` (`sex_no`) ON UPDATE CASCADE;

--
-- Constraints for table `ticket`
--
ALTER TABLE `ticket`
  ADD CONSTRAINT `cons_fk_p1` FOREIGN KEY (`Passengers_no`) REFERENCES `passengers` (`Passengers_no`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cons_fk_p2` FOREIGN KEY (`flight_no`) REFERENCES `flight` (`flight_no`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cons_fk_p3` FOREIGN KEY (`accounts_no`) REFERENCES `accounts` (`accounts_no`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
